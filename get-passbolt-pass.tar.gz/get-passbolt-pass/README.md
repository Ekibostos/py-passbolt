# get-passbolt-pass

Поиск происходит по названию УЗ(name в таблице passbolt)

# Необходимые пакеты

1) pip insall pgpy
2) pip install py-passbolt

# Как использовать

1) Скачать privat key из passbolt. Profile --> key inspector.
2) Заполнить файл config.json.
2.1) Указать хост passbolt
2.2) cat passbolt_private.asc далее скопировать и вставить в поле для ключа.
2.3) указать парольную фразу
3) Запустить скрипт passbolt_get_pass.py



